package com.stefanini.pokemon.service;

public class ServiceBase {

}
