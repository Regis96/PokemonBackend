package com.stefanini.pokemon.entities;

import java.io.Serializable;

public class EntityBase implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	

}
 