package com.stefanini.pokemon.daos;

import java.util.List;

import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import javax.inject.Named;
import javax.persistence.EntityManager;

import com.stefanini.pokemon.dtos.TreinadorDTO;
import com.stefanini.pokemon.entities.Treinador;
import com.stefanini.pokemon.parsers.TreinadorParserDTO;
import com.stefanini.pokemon.persistence.PersistenceSingleton;

@Named
@ApplicationScoped
public class TreinadorDAO extends GenericDAO<Long, Treinador> {

	TreinadorParserDTO parser = new TreinadorParserDTO();
	
	public TreinadorDAO(Class<Treinador> entity) {
		super(entity);
	}

	@Inject
	private EntityManager em;

	public void incluir(TreinadorDTO treinador) {
		Treinador entity = parser.toEntity(treinador);

		this.em.persist(entity);
	}

	public TreinadorDTO getTreinador(Long id) {
		PersistenceSingleton pers = PersistenceSingleton.getInstance();
		Treinador treinador = pers.getTreinador(id);
		TreinadorDTO treinadorDto = parser.toDTO(treinador);
		return treinadorDto;
	}

	public List<Treinador> getTodosTreinadores() {
		return getList();
	}

	public void alterarTreinador(TreinadorDTO treinador) {
		Treinador entity = parser.toEntity(treinador);

		this.em.merge(entity);
	}

	public void excluirTreinador(Long id) {
		Treinador treinador = this.em.getReference(Treinador.class, id);
		this.em.remove(treinador);
	}
}
